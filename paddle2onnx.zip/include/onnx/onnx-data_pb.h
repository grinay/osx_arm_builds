/*
 * SPDX-License-Identifier: Apache-2.0
 */


#pragma once

#include "onnx/onnx_pb.h"
#include "onnx/onnx-data.pb.h"
