#pragma once
#include "onnx_paddle2onnx-ml.pb.h"
