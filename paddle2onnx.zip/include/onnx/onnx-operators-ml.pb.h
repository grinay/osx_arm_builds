#pragma once
#include "onnx-operators_paddle2onnx-ml.pb.h"
